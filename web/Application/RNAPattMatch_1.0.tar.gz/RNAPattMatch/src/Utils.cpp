/*
 * General.cpp
 *
 *  Created on: Sep 16, 2014
 *      Author: matan
 */

#include <Utils.h>

bool Utils::IsFasta(char base, bool isComplete) {
	bool result = true;

	return result;
}
