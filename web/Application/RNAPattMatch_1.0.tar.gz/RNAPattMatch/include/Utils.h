/*
 * General.h
 *
 *  Created on: Sep 16, 2014
 *      Author: matan
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <string>
#include <sys/stat.h>

class Utils {
public:
	static bool IsFasta(char, bool);
};

inline bool exists(const std::string& name) {
		struct stat buffer;
		return (stat(name.c_str(), &buffer) == 0 &&
				buffer.st_size > 0);
}

#endif /* UTILS_H_ */
